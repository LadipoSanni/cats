#!/bin/bash
set -e

echo "Starting Puma service..."
systemctl start puma.service
